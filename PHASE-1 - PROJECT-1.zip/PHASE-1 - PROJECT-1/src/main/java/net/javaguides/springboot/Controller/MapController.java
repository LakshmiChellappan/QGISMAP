package net.javaguides.springboot.Controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import net.javaguides.springboot.model.State;
import net.javaguides.springboot.repository.StateRepository;
import net.javaguides.springboot.service.StateService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MapController {
    private final StateRepository stateRepository;
    private final ObjectMapper objectMapper;

    public MapController(StateRepository stateRepository, ObjectMapper objectMapper) {
        this.stateRepository = stateRepository;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/map")
    public String showMap(Model model) {
        List<State> states = stateRepository.findAll();
        String statesJson = "[]";
        try {
            statesJson = objectMapper.writeValueAsString(states);
        } catch (JsonProcessingException e) {
            // Handle the exception if needed
            e.printStackTrace();
        }
        model.addAttribute("states", statesJson);
        return "map";
    }

}

