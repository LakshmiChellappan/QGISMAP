package net.javaguides.springboot.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

	@GetMapping(value="/login",produces = "text/html")
	public String login() {
		return "auth-login";
	}
	
	@GetMapping("/")
	public String home()
	{
		return "index";
	}






	}








