package net.javaguides.springboot.web;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RetrieveDataAsJsonArray {

    public static void main(String[] args) {
        // Database connection details
        String url = "jdbc:postgresql://localhost:5433/postgis_33_sample";
        String username = "postgres";
        String password = "tiger";


        String name_file="name";
        String geometric_name="geometric";
        String ipAdress="ip";
        String userConnectedName="userConnected";
        String networkStatusName="networkStatus";

        // SQL query to retrieve data as JSON
        String query = "SELECT name, geometric, ip, user_connected, network_status FROM states";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            // Create a JSON array object
            StringBuilder json = new StringBuilder();
            json.append("var states = [");

            // Iterate over the result set and append each row as a JSON object
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String geometric = resultSet.getString("geometric");
                String ip = resultSet.getString("ip");
                int userConnected = resultSet.getInt("user_connected");
                String networkStatus = resultSet.getString("network_status");

                String[] coordinates = geometric.substring(1, geometric.length() - 1).split(",");
                String geometric_y = coordinates[0].trim();
                String geometric_x = coordinates[1].trim();


                // Append the JSON object to the array
                json.append("{");
                json.append(name_file).append(":").append("\"").append(name).append("\"").append(",");
                json.append(geometric_name).append(":").append("{ y:").append(geometric_y).append(",x:").append(geometric_x).append("}").append(",");
                json.append(ipAdress).append(":").append("\"").append(ip).append("\"").append(",");
                json.append(userConnectedName).append(":").append(userConnected).append(",");
                json.append(networkStatusName).append(":").append("\"").append(networkStatus).append("\"");
                json.append("},");
            }

            // Remove the trailing comma and close the array
            if (json.length() > 1) {
                json.deleteCharAt(json.length() - 1);
            }
            json.append("];");

            // Write the JSON array to the data.js file
            String filePath = "src/main/resources/static/data.js";
            FileWriter fileWriter = new FileWriter(filePath);
            fileWriter.write(json.toString());
            fileWriter.close();

            System.out.println("Data saved to data.json.js successfully.");

        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
}
