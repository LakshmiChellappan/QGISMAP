package net.javaguides.springboot.repository;

import net.javaguides.springboot.model.State;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StateRepository extends JpaRepository<State, Long> {
    // Add custom query methods if needed
}
