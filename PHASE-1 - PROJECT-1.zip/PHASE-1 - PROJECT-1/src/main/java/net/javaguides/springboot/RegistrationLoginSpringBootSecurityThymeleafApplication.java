package net.javaguides.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootApplication
public class RegistrationLoginSpringBootSecurityThymeleafApplication extends WebMvcConfigurerAdapter {
	public static void main(String[] args) throws Exception{
		SpringApplication.run(RegistrationLoginSpringBootSecurityThymeleafApplication.class, args);



	}
}
