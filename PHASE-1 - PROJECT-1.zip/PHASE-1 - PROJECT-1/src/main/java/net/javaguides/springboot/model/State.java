package net.javaguides.springboot.model;


import javax.persistence.*;
import java.awt.*;

@Entity
@Table(name = "states")
public class State {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(name = "geometric")
    private Point geometric;

    private String ip;

    @Column(name = "user_connected")
    private int userConnected;

    @Column(name = "network_status")
    private String networkStatus;

    public State() {
    }



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Point getGeometric() {
        return geometric;
    }

    public void setGeometric(Point geometric) {
        this.geometric = geometric;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getUserConnected() {
        return userConnected;
    }

    public void setUserConnected(int userConnected) {
        this.userConnected = userConnected;
    }

    public String getNetworkStatus() {
        return networkStatus;
    }

    public void setNetworkStatus(String networkStatus) {
        this.networkStatus = networkStatus;
    }

    public State(Long id, String name, Point geometric, String ip, int userConnected, String networkStatus) {
        this.id = id;
        this.name = name;
        this.geometric = geometric;
        this.ip = ip;
        this.userConnected = userConnected;
        this.networkStatus = networkStatus;
    }

    @Override
    public String toString() {
        return "State{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", geometric=" + geometric +
                ", ip='" + ip + '\'' +
                ", userConnected=" + userConnected +
                ", networkStatus='" + networkStatus + '\'' +
                '}';
    }
}
